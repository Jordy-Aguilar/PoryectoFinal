import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class ElectionGUI extends JFrame {
    private ProcesoElectoral elecciones;

    public ElectionGUI() {
        elecciones = new ProcesoElectoral();
        setTitle("Sistema Electoral");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mostrarPantallaBienvenida();
    }

    private void mostrarPantallaBienvenida() {
        // Crear la pantalla de bienvenida
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Bienvenido al Sistema Electoral de la UDLA", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 24));

        // Añadir la imagen de la bandera (reemplazar con la ruta real de la imagen)
        ImageIcon flagIcon = new ImageIcon("path_to_ecuador_flag.jpg");
        JLabel flagLabel = new JLabel(flagIcon);

        // Añadir los componentes al panel de bienvenida
        welcomePanel.add(welcomeLabel, BorderLayout.NORTH);
        welcomePanel.add(flagLabel, BorderLayout.CENTER);

        // Mostrar el panel de bienvenida por unos segundos y luego mostrar la interfaz principal
        add(welcomePanel);
        pack(); // Ajustar el tamaño de la ventana al contenido
        setLocationRelativeTo(null); // Centrar ventana
        setVisible(true);

        // Temporizador para mostrar la interfaz principal después de un tiempo
        Timer timer = new Timer(3000, e -> {
            remove(welcomePanel); // Eliminar el panel de bienvenida
            initializeMainInterface(); // Inicializar la interfaz principal del sistema electoral
            setTitle("Sistema Electoral Profesional"); // Cambiar el título de la ventana
            revalidate();
            repaint();
        });
        timer.setRepeats(false);
        timer.start();
    }

    private void initializeMainInterface() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(mainPanel);

        Font buttonFont = new Font("Arial", Font.BOLD, 18);

        JButton registerVoterButton = createStyledButton("Registro de votantes", buttonFont, Color.BLUE, Color.WHITE);
        registerVoterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelRegistroVotante();
            }
        });
        mainPanel.add(registerVoterButton);

        JButton registerCandidateButton = createStyledButton("Registrar su candidatura", buttonFont, Color.ORANGE, Color.WHITE);
        registerCandidateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPanelRegistroCandidato();
            }
        });
        mainPanel.add(registerCandidateButton);

        JButton voteButton = createStyledButton("Emitir voto", buttonFont, Color.GREEN, Color.WHITE);
        voteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para la emisión de voto
                // Agrega aquí la lógica correspondiente
            }
        });
        mainPanel.add(voteButton);

        JButton showResultsButton = createStyledButton("Mostrar resultados", buttonFont, Color.RED, Color.WHITE);
        showResultsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarResultados();
            }
        });
        mainPanel.add(showResultsButton);
    }

    private JButton createStyledButton(String text, Font font, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setFont(font);
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setOpaque(true);
        button.setBorderPainted(false);
        return button;
    }

    private void mostrarPanelRegistroVotante() {
        JPanel registerVoterPanel = new JPanel(new GridLayout(0, 2, 10, 10));

        registerVoterPanel.add(new JLabel("Nombre:"));
        JTextField voterNameField = new JTextField(10);
        registerVoterPanel.add(voterNameField);

        registerVoterPanel.add(new JLabel("Cédula:"));
        JTextField voterIdField = new JTextField(10);
        registerVoterPanel.add(voterIdField);

        registerVoterPanel.add(new JLabel("Dirección:"));
        JTextField voterAddressField = new JTextField(10);
        registerVoterPanel.add(voterAddressField);

        JButton registerVoterButton = new JButton("Registrar Votante");
        registerVoterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = voterNameField.getText();
                String cedula = voterIdField.getText();
                String direccion = voterAddressField.getText();

                // Agrega aquí la lógica correspondiente para registrar el votante
                // Por ejemplo, puedes llamar a un método de tu clase ProcesoElectoral para realizar el registro
                elecciones.registrarVotante(new Votante(nombre, cedula, direccion));
            }
        });
        registerVoterPanel.add(registerVoterButton);

        JOptionPane.showMessageDialog(this, registerVoterPanel, "Registro de Votante", JOptionPane.PLAIN_MESSAGE);
    }

    private void mostrarPanelRegistroCandidato() {
        JPanel registerCandidatePanel = new JPanel(new GridLayout(0, 2, 10, 10));

        registerCandidatePanel.add(new JLabel("Nombre:"));
        JTextField candidateNameField = new JTextField(10);
        registerCandidatePanel.add(candidateNameField);

        registerCandidatePanel.add(new JLabel("Cédula:"));
        JTextField candidateIdField = new JTextField(10);
        registerCandidatePanel.add(candidateIdField);

        registerCandidatePanel.add(new JLabel("Partido Político:"));
        JTextField candidatePartyField = new JTextField(10);
        registerCandidatePanel.add(candidatePartyField);

        registerCandidatePanel.add(new JLabel("Fecha de Nacimiento:"));
        JTextField candidateBirthDateField = new JTextField(10);
        registerCandidatePanel.add(candidateBirthDateField);

        String[] generoOptions = {"Masculino", "Femenino"};
        JComboBox<String> generoComboBox = new JComboBox<>(generoOptions);
        registerCandidatePanel.add(new JLabel("Género:"));
        registerCandidatePanel.add(generoComboBox);

        registerCandidatePanel.add(new JLabel("Número de Teléfono:"));
        JTextField candidatePhoneNumberField = new JTextField(10);
        registerCandidatePanel.add(candidatePhoneNumberField);

        JButton registerCandidateButton = new JButton("Registrar Candidato");
        registerCandidateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = candidateNameField.getText();
                String cedula = candidateIdField.getText();
                String partidoPolitico = candidatePartyField.getText();
                String fechaNacimiento = candidateBirthDateField.getText();
                String genero = (String) generoComboBox.getSelectedItem();
                String numeroTelefono = candidatePhoneNumberField.getText();

                // Agrega aquí la lógica correspondiente para registrar el candidato
                // Por ejemplo, puedes llamar a un método de tu clase ProcesoElectoral para realizar el registro
                elecciones.registrarCandidato(new Candidato(nombre, cedula, partidoPolitico, fechaNacimiento, genero, numeroTelefono));
            }
        });
        registerCandidatePanel.add(registerCandidateButton);

        JOptionPane.showMessageDialog(this, registerCandidatePanel, "Registro de Candidato", JOptionPane.PLAIN_MESSAGE);
    }

    private void mostrarResultados() {
        // Lógica para mostrar resultados
        // Suponiendo que tienes una forma de obtener los resultados de la votación
        Map<String, Integer> resultados = obtenerResultados(); // Método ficticio para obtener resultados

        // Crear un gráfico simple de barras con los resultados
        JFrame chartFrame = new JFrame("Resultados de la Elección");
        chartFrame.setSize(600, 400);
        chartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                int barWidth = 50;
                int spacing = 10;
                int x = 50;
                int maxHeight = 300;

                for (Map.Entry<String, Integer> entry : resultados.entrySet()) {
                    int barHeight = (int) (((double) entry.getValue() / getMaxValue(resultados)) * maxHeight);
                    g.setColor(Color.BLUE);
                    g.fillRect(x, getHeight() - barHeight, barWidth, barHeight);
                    g.setColor(Color.BLACK);
                    g.drawString(entry.getKey(), x + barWidth / 2 - 20, getHeight() - 5);
                    x += barWidth + spacing;
                }
            }
        };

        chartFrame.add(chartPanel);
        chartFrame.setVisible(true);
    }

    private int getMaxValue(Map<String, Integer> resultados) {
        return resultados.values().stream().mapToInt(Integer::intValue).max().orElse(0);
    }

    private Map<String, Integer> obtenerResultados() {
        // Método ficticio para obtener resultados (deberás implementar según tu lógica)
        Map<String, Integer> resultados = new HashMap<>();
        resultados.put("Candidato A", 150);
        resultados.put("Candidato B", 200);
        resultados.put("Candidato C", 120);
        return resultados;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ElectionGUI();
        });
    }
}